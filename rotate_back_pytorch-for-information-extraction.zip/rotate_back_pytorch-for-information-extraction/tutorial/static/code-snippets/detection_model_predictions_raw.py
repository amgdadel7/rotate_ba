print(detection_predictions[0]['labels'].size()[0], 'objects detected !')
detection_predictions[0]