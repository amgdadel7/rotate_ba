# call test function 
test_orientation_model(orientation_model, orientation_criterion, orientation_loaders, use_cuda= False)